function Saison({ episodes, selectedSeason, onSeasonChange }) {
    // Création de la liste des saisons disponibles sans utiliser Set
    const seasons = episodes.reduce((acc, episode) => {
      if (!acc.includes(episode.season)) {
        acc.push(episode.season);
      }
      return acc;
    }, []);
    
    // Filtrage des épisodes par saison sélectionnée
    const filteredEpisodes = episodes.filter(episode => episode.season === selectedSeason);
  
    return (
      <div>
        {/* Sélecteur de saison */}
        <label htmlFor="season-select">Sélectionnez une saison:</label>
        <select id="season-select" value={selectedSeason} onChange={onSeasonChange}>
          {seasons.map((season) => (
            <option key={season} value={season}>
              Saison {season}
            </option>
          ))}
        </select>
  
        {/* Affichage des épisodes de la saison sélectionnée */}
        <h2>Épisodes de la Saison {selectedSeason}:</h2>
        {filteredEpisodes.length > 0 ? (
          <ul>
            {filteredEpisodes.map((episode) => (
              <li key={episode.id}>
                <a href={episode.url} target="_blank" rel="noopener noreferrer">
                  {episode.name}
                </a>
                <p>{episode.summary?.replace(/<\/?[^>]+(>|$)/g, "") || "Pas de résumé disponible."}</p>
                {episode.image && <img src={episode.image.medium} alt={episode.name} />}
              </li>
            ))}
          </ul>
        ) : (
          <p>Pas d'informations sur les épisodes disponibles.</p>
        )}
      </div>
    );
  }
  
  export default Saison;
  